package com.example.hotel.dto.supplier;


import com.fasterxml.jackson.annotation.JsonProperty;

public class Hotel {
    @JsonProperty("HCode")
    private String hCode;
    @JsonProperty("HName")
    private String hName;
    @JsonProperty("Available")
    private boolean available;
    @JsonProperty("Amount")
    private double amount;

    // getters and setters
    public String getHCode() { return hCode; }
    public void setHCode(String hCode) { this.hCode = hCode; }

    public String getHName() { return hName; }
    public void setHName(String hName) { this.hName = hName; }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }
}

