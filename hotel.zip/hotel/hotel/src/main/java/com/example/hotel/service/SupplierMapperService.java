package com.example.hotel.service;

import com.example.hotel.dto.common.*;
import com.example.hotel.dto.supplier.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SupplierMapperService {

    public SuplierRequestDto toSupplierRequest(CommonRequestDto commonRequest) {
        SuplierRequestDto dto = new SuplierRequestDto();
        dto.setCityId(commonRequest.getCityId());
        dto.setNationalityId(commonRequest.getNationalityId());
        dto.setCheckInDate(commonRequest.getCheckIn());
        dto.setCheckOutDate(commonRequest.getCheckOut());

        List<RoomDetail> roomDetails = new ArrayList<>();
        for (Room room : commonRequest.getRooms()) {
            RoomDetail rd = new RoomDetail();
            rd.setNoOfAdult(room.getaDT());
            rd.setNoOfChild(room.getcHD());
            rd.setChildAges(room.getChildAges());
            roomDetails.add(rd);
        }

        dto.setRoomDetail(new ArrayList<>(roomDetails));
        return dto;
    }

    public CommonResponseDto toCommonResponse(SupplierResponseDto supplierResponse) {
        CommonResponseDto dto = new CommonResponseDto();
        dto.setSearchId(supplierResponse.getTokenId());

        List<HotelResponse> hotels = new ArrayList<>();
        for (Hotel h : supplierResponse.getHotels()) {
            HotelResponse hr = new HotelResponse();
            hr.setCode(h.getHCode());
            hr.setName(h.getHName());
            hr.setAmount(h.getAmount());
            hr.setCurrency(supplierResponse.getCurrency());
            hotels.add(hr);
        }

        dto.setHotels(new ArrayList<>(hotels));
        return dto;
    }
}
