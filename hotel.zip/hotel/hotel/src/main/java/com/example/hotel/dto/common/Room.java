package com.example.hotel.dto.common;


import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;

public class Room {
    @JsonProperty("ADT")
    private int aDT;
    @JsonProperty("CHD")
    private int cHD;
    @JsonProperty("ChildAges")
    private ArrayList<Integer> childAges;

    // getters and setters
    public int getaDT() { return aDT; }
    public void setaDT(int aDT) { this.aDT = aDT; }

    public int getcHD() { return cHD; }
    public void setcHD(int cHD) { this.cHD = cHD; }

    public ArrayList<Integer> getChildAges() { return childAges; }
    public void setChildAges(ArrayList<Integer> childAges) { this.childAges = childAges; }
}
