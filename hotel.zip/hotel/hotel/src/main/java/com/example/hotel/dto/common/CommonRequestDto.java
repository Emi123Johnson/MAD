package com.example.hotel.dto.common;


import java.util.ArrayList;

public class CommonRequestDto {
    private int cityId;
    private String nationalityId;
    private String checkIn;
    private String checkOut;
    private ArrayList<Room> rooms;

    // getters and setters
    public int getCityId() { return cityId; }
    public void setCityId(int cityId) { this.cityId = cityId; }

    public String getNationalityId() { return nationalityId; }
    public void setNationalityId(String nationalityId) { this.nationalityId = nationalityId; }

    public String getCheckIn() { return checkIn; }
    public void setCheckIn(String checkIn) { this.checkIn = checkIn; }

    public String getCheckOut() { return checkOut; }
    public void setCheckOut(String checkOut) { this.checkOut = checkOut; }

    public ArrayList<Room> getRooms() { return rooms; }
    public void setRooms(ArrayList<Room> rooms) { this.rooms = rooms; }
}
