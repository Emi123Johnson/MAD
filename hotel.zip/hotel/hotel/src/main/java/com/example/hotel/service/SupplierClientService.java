package com.example.hotel.service;

import com.example.hotel.dto.supplier.SuplierRequestDto;
import com.example.hotel.dto.supplier.SupplierResponseDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

@Service
public class SupplierClientService {

    private final RestClient restClient;

    public SupplierClientService(
            @Value("${supplier.api.url}") String supplierUrl,
            @Value("${supplier.api.username}") String username,
            @Value("${supplier.api.password}") String password
    ) {
        this.restClient = RestClient.builder()
                .baseUrl(supplierUrl)   // 👈 Base URL
                .defaultHeaders(headers -> headers.setBasicAuth(username, password)) // 👈 Basic Auth
                .build();
    }

    public SupplierResponseDto callSupplier(SuplierRequestDto request) {
        return restClient.post()
                .uri("/search")   // 👈 relative path, final URL -> {supplierUrl}/search
                .body(request)
                .retrieve()
                .body(SupplierResponseDto.class);
    }
}
