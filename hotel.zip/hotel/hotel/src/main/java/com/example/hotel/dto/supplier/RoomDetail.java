package com.example.hotel.dto.supplier;


import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;

public class RoomDetail {
    @JsonProperty("RoomSrNo")
    private int roomSrNo;
    @JsonProperty("NoOfAdult")
    private int noOfAdult;
    @JsonProperty("NoOfChild")
    private int noOfChild;
    @JsonProperty("ChildAges")
    private ArrayList<Integer> childAges;

    // getters and setters
    public int getRoomSrNo() { return roomSrNo; }
    public void setRoomSrNo(int roomSrNo) { this.roomSrNo = roomSrNo; }

    public int getNoOfAdult() { return noOfAdult; }
    public void setNoOfAdult(int noOfAdult) { this.noOfAdult = noOfAdult; }

    public int getNoOfChild() { return noOfChild; }
    public void setNoOfChild(int noOfChild) { this.noOfChild = noOfChild; }

    public ArrayList<Integer> getChildAges() { return childAges; }
    public void setChildAges(ArrayList<Integer> childAges) { this.childAges = childAges; }
}
