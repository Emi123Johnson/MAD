package com.example.hotel.dto.common;


import java.util.ArrayList;

public class CommonResponseDto {
    private String searchId;
    private ArrayList<HotelResponse> hotels;

    // getters and setters
    public String getSearchId() { return searchId; }
    public void setSearchId(String searchId) { this.searchId = searchId; }

    public ArrayList<HotelResponse> getHotels() { return hotels; }
    public void setHotels(ArrayList<HotelResponse> hotels) { this.hotels = hotels; }
}
