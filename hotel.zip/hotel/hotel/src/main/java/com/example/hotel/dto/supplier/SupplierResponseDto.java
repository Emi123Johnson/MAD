package com.example.hotel.dto.supplier;


import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;

public class SupplierResponseDto {
    @JsonProperty("Currency")
    private String currency;
    @JsonProperty("TokenId")
    private String tokenId;
    @JsonProperty("Hotels")
    private ArrayList<Hotel> hotels;

    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }

    public String getTokenId() { return tokenId; }
    public void setTokenId(String tokenId) { this.tokenId = tokenId; }

    public ArrayList<Hotel> getHotels() { return hotels; }
    public void setHotels(ArrayList<Hotel> hotels) { this.hotels = hotels; }
}
