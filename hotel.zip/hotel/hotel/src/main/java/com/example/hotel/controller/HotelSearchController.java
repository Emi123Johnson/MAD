package com.example.hotel.controller;

import com.example.hotel.dto.common.CommonRequestDto;
import com.example.hotel.dto.common.CommonResponseDto;
import com.example.hotel.dto.supplier.SuplierRequestDto;
import com.example.hotel.dto.supplier.SupplierResponseDto;
import com.example.hotel.service.SupplierMapperService;
import com.example.hotel.service.SupplierClientService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/hotels")
public class HotelSearchController {
	

    private final SupplierMapperService mapperService;
    private final SupplierClientService clientService;

    public HotelSearchController(SupplierMapperService mapperService, SupplierClientService clientService) {
        this.mapperService = mapperService;
        this.clientService = clientService;
    }

    @PostMapping("/search")
    public ResponseEntity<CommonResponseDto> searchHotels(@RequestBody CommonRequestDto request) {
        // step 1: convert common → supplier
        SuplierRequestDto supplierRequest = mapperService.toSupplierRequest(request);

        // step 2: call supplier API
        SupplierResponseDto supplierResponse = clientService.callSupplier(supplierRequest);

        // step 3: convert supplier → common
        CommonResponseDto response = mapperService.toCommonResponse(supplierResponse);

        return ResponseEntity.ok(response);
    }
}
