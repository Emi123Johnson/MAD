package com.example.hotel.dto.supplier;


import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.ArrayList;

public class SuplierRequestDto {
    @JsonProperty("CityId")
    private int cityId;
    @JsonProperty("NationalityId")
    private String nationalityId;
    @JsonProperty("CheckInDate")
    private String checkInDate;
    @JsonProperty("CheckOutDate")
    private String checkOutDate;
    @JsonProperty("HCodes")
    private String hCodes;
    @JsonProperty("RoomDetail")
    private ArrayList<RoomDetail> roomDetail;

    // getters and setters
    public int getCityId() { return cityId; }
    public void setCityId(int cityId) { this.cityId = cityId; }

    public String getNationalityId() { return nationalityId; }
    public void setNationalityId(String nationalityId) { this.nationalityId = nationalityId; }

    public String getCheckInDate() { return checkInDate; }
    public void setCheckInDate(String checkInDate) { this.checkInDate = checkInDate; }

    public String getCheckOutDate() { return checkOutDate; }
    public void setCheckOutDate(String checkOutDate) { this.checkOutDate = checkOutDate; }

    public String getHCodes() { return hCodes; }
    public void setHCodes(String hCodes) { this.hCodes = hCodes; }

    public ArrayList<RoomDetail> getRoomDetail() { return roomDetail; }
    public void setRoomDetail(ArrayList<RoomDetail> roomDetail) { this.roomDetail = roomDetail; }
}

