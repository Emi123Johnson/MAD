package com.unimoni.ottila;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelOttilaAdapterApplicationTests {

	@Test
	void contextLoads() {
	}

}
