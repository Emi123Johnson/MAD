package com.unimoni.ottila.dto.common.search.response;

import java.util.List;

import lombok.Data;
@Data
public class HotelSearchResponse {
	public String currency;
    public String tokenId;
    public List<Hotel> hotels;

}
