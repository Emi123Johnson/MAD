package com.unimoni.ottila.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.unimoni.ottila.dto.common.search.request.HotelSearchRequest;
import com.unimoni.ottila.dto.common.search.request.PaxRoomsDetail;
import com.unimoni.ottila.dto.common.search.response.HotelSearchResponse;
import com.unimoni.ottila.dto.search.request.RoomDetail;
import com.unimoni.ottila.dto.search.request.SearchRequest;
import com.unimoni.ottila.dto.search.response.SearchResponse;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class SearchService {

	private final OttilaApiClient ottilaApiClient;
	private final OttilaResponseMapper ottilaResponseMapper;

	public HotelSearchResponse search(HotelSearchRequest request) {
		SearchRequest searchRequest = toSupplierRequest(request);

		System.out.println("2>>>" + searchRequest);
		SearchResponse searchResponse = ottilaApiClient.callSupplierApi(searchRequest);

		System.out.println("3>>>" + searchResponse);

		return ottilaResponseMapper.toCommonResponse(searchResponse);
	}

	public SearchRequest toSupplierRequest(HotelSearchRequest request) {
		SearchRequest supplierRequest = new SearchRequest();

		supplierRequest.setCityId(request.getCityId());
		supplierRequest.setNationalityId("1");
		supplierRequest.setCheckInDate(request.getCheckIn());
		supplierRequest.setCheckOutDate(request.getCheckOut());

		supplierRequest.setHCode(String.join(",", request.getHotelCodes()));

		List<RoomDetail> roomDetails = new ArrayList<>();
		int srNo = 1;

		for (PaxRoomsDetail pax : request.getPaxRoomsDetails()) {
			RoomDetail rd = new RoomDetail();
			rd.setRoomSrNo(srNo++);
			rd.setNoOfAdult(pax.getAdults());
			rd.setNoOfChild(pax.getChildren());
			rd.setChildAges(pax.getChildrenAges());
			roomDetails.add(rd);
		}
		supplierRequest.setRoomDetail(roomDetails);

		return supplierRequest;
	}
}
