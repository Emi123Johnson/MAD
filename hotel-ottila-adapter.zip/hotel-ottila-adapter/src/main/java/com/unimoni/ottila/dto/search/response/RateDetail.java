package com.unimoni.ottila.dto.search.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class RateDetail {
	 @JsonProperty("Index") 
	 	private int index;
	    @JsonProperty("RoomSrNo") 
	    private String roomSrNo;
	    @JsonProperty("RoomCategory") 
	    private String roomCategory;
	    @JsonProperty("Meal") 
	    private String meal;
	    @JsonProperty("Available") 
	    private boolean available;
	    @JsonProperty("Amount") 
	    private double amount;
	    @JsonProperty("DeadLineDate") 
	    private String deadLineDate;
	    @JsonProperty("RateKey") 
	    private String rateKey;
	    @JsonProperty("PackageRate") 
	    private boolean packageRate;

}
