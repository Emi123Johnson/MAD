package com.unimoni.ottila.dto.common.search.request;

import java.util.List;

import lombok.Data;
@Data
public class PaxRoomsDetail {
	 	private int adults;
	 	private int children;
	 	private List<Integer> childrenAges;
}
