package com.unimoni.ottila.dto.common.prebook.response;

public class HotelPreBookResponse {

}
