package com.unimoni.ottila.dto.common.prebook.request;

public class HotelPreBookRequest {

}
