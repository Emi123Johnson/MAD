package com.unimoni.ottila.dto.search.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SearchRequest {
	@JsonProperty("CityId")
	private int cityId;
	@JsonProperty("NationalityId")
	private String nationalityId;
	@JsonProperty("CheckInDate")
	private String checkInDate;
	@JsonProperty("CheckOutDate")
	private String checkOutDate;
	@JsonProperty("HCode")
	private String hCode;
	@JsonProperty("RoomDetail")
	private List<RoomDetail> roomDetail;

}
