package com.unimoni.ottila.dto.search.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class Vendor {
	@JsonProperty("HKey")
	private String hKey;
	@JsonProperty("RateDetails")
	private List<RateDetail> rateDetails;
	@JsonProperty("FixedOption")
	private boolean fixedOption;
	@JsonProperty("Options")
	private List<String> options;

}
