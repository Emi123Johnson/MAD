package com.unimoni.ottila.dto.common.search.response;

import lombok.Data;

@Data
public class DayRate {
	private double basePrice;
}
