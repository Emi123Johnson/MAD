package com.unimoni.ottila.dto.ottila.prebook.response;

public class PreBookResponse {

}
