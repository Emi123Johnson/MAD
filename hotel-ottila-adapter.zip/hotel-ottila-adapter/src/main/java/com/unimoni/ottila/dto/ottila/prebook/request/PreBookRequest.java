package com.unimoni.ottila.dto.ottila.prebook.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PreBookRequest {
	 @JsonProperty("CityId") 
	    public int cityId;
	    @JsonProperty("NationalityId") 
	    public int nationalityId;
	    @JsonProperty("CheckInDate") 
	    public String checkInDate;
	    @JsonProperty("CheckOutDate") 
	    public String checkOutDate;
	    @JsonProperty("HCode") 
	    public String hCode;
	    @JsonProperty("TokenId") 
	    public String tokenId;
	    @JsonProperty("HKey") 
	    public String hKey;
	    @JsonProperty("RoomDetail") 
	    public List<PreBookRoomDetail> roomDetail;

}
