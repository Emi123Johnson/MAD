package com.unimoni.ottila.dto.search.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class OttilaHotel {
	
	    @JsonProperty("HCode") 
	    private String hCode;
	    @JsonProperty("HName") 
	    private String hName;
	    @JsonProperty("VendorList") 
	    private List<Vendor> vendorList;
	

}
