package com.unimoni.ottila.dto.search.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class RoomDetail {
	@JsonProperty("RoomSrNo")
	private int roomSrNo;
	@JsonProperty("NoOfAdult")
	private int noOfAdult;
	@JsonProperty("NoOfChild")
	private int noOfChild;
	@JsonProperty("ChildAges")
	private List<Integer> childAges;

}
