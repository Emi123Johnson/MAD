package com.unimoni.ottila.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.unimoni.ottila.dto.common.search.response.Hotel;
import com.unimoni.ottila.dto.common.search.response.HotelSearchResponse;
import com.unimoni.ottila.dto.common.search.response.Room;
import com.unimoni.ottila.dto.search.response.OttilaHotel;
import com.unimoni.ottila.dto.search.response.RateDetail;
import com.unimoni.ottila.dto.search.response.SearchResponse;
import com.unimoni.ottila.dto.search.response.Vendor;

@Service
public class OttilaResponseMapper {
	public HotelSearchResponse toCommonResponse(SearchResponse response) {

		HotelSearchResponse commonResponse = new HotelSearchResponse();
		commonResponse.setCurrency(response.getCurrency());
		commonResponse.setTokenId(response.getTokenId());
		List<Hotel> commonHotels = new ArrayList<>();
		for (OttilaHotel supplierHotel : response.getHotels()) {
			Hotel commonHotel = new Hotel();
			commonHotel.setHotelCode(supplierHotel.getHCode());
			commonHotel.setHotelName(supplierHotel.getHName());

			List<Room> commonRooms = new ArrayList<>();
			for (Vendor vendor : supplierHotel.getVendorList()) {
				for (RateDetail rate : vendor.getRateDetails()) {
					Room commonRoom = new Room();
					commonRoom.setRoomCategory(rate.getRoomCategory());
					commonRoom.setBookingCode(rate.getRateKey());
					commonRoom.setMealType(rate.getMeal());
					commonRoom.setRefundable(false);
					commonRoom.setTotalFare(rate.getAmount());
					commonRooms.add(commonRoom);
				}
			}

			commonHotel.setRooms(commonRooms);
			commonHotels.add(commonHotel);
		}

		commonResponse.setHotels(commonHotels);

		return commonResponse;
	}
}
