package com.unimoni.ottila.dto.ottila.prebook.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class PreBookRoomDetail{
    @JsonProperty("RoomSrNo") 
    public int roomSrNo;
    @JsonProperty("NoOfAdult") 
    public int noOfAdult;
    @JsonProperty("NoOfChild") 
    public int noOfChild;
    @JsonProperty("ChildAges") 
    public List<Integer> childAges;
    @JsonProperty("RateKey") 
    public String rateKey;
}
