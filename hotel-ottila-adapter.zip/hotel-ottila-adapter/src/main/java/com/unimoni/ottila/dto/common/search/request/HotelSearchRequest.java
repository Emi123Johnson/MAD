package com.unimoni.ottila.dto.common.search.request;

import java.util.List;

import lombok.Data;

@Data
public class HotelSearchRequest {
	private int cityId;
	private String guestNationality;
	private String checkIn;
	private String checkOut;
	private List<String> hotelCodes;
	private List<PaxRoomsDetail> paxRoomsDetails;
	private SearchFilters searchFilters;
	private boolean isDetailedResponse;

}
