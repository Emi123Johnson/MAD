package com.unimoni.ottila.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

@Configuration
public class RestClientConfig {
	
	@Value("${supplier.api.base-url}")
	private String baseUrl;

	@Value("${supplier.api.username}")
	private String username;

	@Value("${supplier.api.password}")
	private String password;

	@Bean
	RestClient restClient(RestClient.Builder builder) {
		return builder.baseUrl(baseUrl).defaultHeader("Accept", "application/json").defaultHeader("UserName", username)
				.defaultHeader("Password", password).build();
	}
}