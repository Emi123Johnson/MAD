package com.unimoni.ottila.dto.common.search.request;

import lombok.Data;

@Data
public class SearchFilters {
	private boolean refundable;
	private String mealType;
	private String starRating;
}
