package com.unimoni.ottila.dto.common.search.response;

import java.util.List;

import lombok.Data;

@Data
public class Room {
	 private String roomCategory;
	 private String bookingCode;
	 private String mealType;
	 private boolean isRefundable;
	 private List<String> inclusions;
	 private List<String> promotions;
	 private List<DayRate> dayRates;
	 private double totalFare;
	 private List<CancellationPolicy> cancellationPolicies;
	 private boolean withTransfers;
}
