package com.unimoni.ottila.dto.common.search.response;

import lombok.Data;

@Data
public class CancellationPolicy {
	private String fromDate;
	private String chargeType;
	private int cancellationCharge;

}
