package com.unimoni.ottila.dto.search.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class SearchResponse {
	@JsonProperty("Currency")
	private String currency;
	@JsonProperty("TokenId")
	private String tokenId;
	@JsonProperty("Hotels")
	private List<OttilaHotel> hotels;
}
