package com.unimoni.ottila.dto.common.search.response;

import java.util.List;

import lombok.Data;

@Data
public class Hotel {
	private String hotelCode;
	private String hotelName;
	private List<Room> rooms;
}
