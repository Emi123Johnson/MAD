package com.unimoni.ottila.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.unimoni.ottila.dto.search.request.SearchRequest;
import com.unimoni.ottila.dto.search.response.SearchResponse;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class OttilaApiClient {

	private final RestClient restClient;
	private final ObjectMapper objectMapper;

	public SearchResponse callSupplierApi(SearchRequest request) {

		SearchResponse supplierResponse = restClient.post().uri("/Availability/1/HSearchByHotelCode_V2").body(request)
				.retrieve().body(SearchResponse.class);
		try {
			log.info("supplierResponse {}", objectMapper.writeValueAsString(supplierResponse));
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return supplierResponse;
	}
}