package com.unimoni.ottila.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.unimoni.ottila.dto.common.search.request.HotelSearchRequest;
import com.unimoni.ottila.dto.common.search.response.HotelSearchResponse;
import com.unimoni.ottila.service.OttilaResponseMapper;
import com.unimoni.ottila.service.SearchService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
public class SearchController {

	private final SearchService supplierRequestService;
	private final OttilaResponseMapper ResponseMapper;
	@PostMapping("/search")
	public HotelSearchResponse convertRequest(@RequestBody HotelSearchRequest request) {
		log.info("request {}",request);
		return supplierRequestService.search(request);
	}
}
